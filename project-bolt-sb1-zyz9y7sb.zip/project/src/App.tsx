import React, { useState } from 'react';
import { Brain } from 'lucide-react';
import { EmailInput } from './components/EmailInput';
import { ResultDisplay } from './components/ResultDisplay';
import { ClassificationResult } from './types';
import { analyzeEmail } from './utils/spamDetection';

function App() {
  const [result, setResult] = useState<ClassificationResult | null>(null);

  const handleEmailSubmit = (content: string) => {
    const analysis = analyzeEmail(content);
    setResult(analysis);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Brain className="w-10 h-10 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-800">
              Spam Email Classification System
            </h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Analyze email content using advanced Natural Language Processing and Machine Learning
            techniques to detect spam messages.
          </p>
        </div>

        <div className="flex flex-col items-center gap-6">
          <EmailInput onSubmit={handleEmailSubmit} />
          <ResultDisplay result={result} />
        </div>
      </div>
    </div>
  );
}

export default App;