import React, { useState } from 'react';
import { Mail, AlertCircle } from 'lucide-react';
import { validateEmail } from '../utils/validation';

interface EmailInputProps {
  onSubmit: (content: string) => void;
}

export const EmailInput: React.FC<EmailInputProps> = ({ onSubmit }) => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateEmail(email);
    
    if (!validation.isValid) {
      setError(validation.message);
      return;
    }

    setError('');
    onSubmit(email);
    setEmail('');
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-2 mb-4">
          <Mail className="w-5 h-5 text-blue-600" />
          <h2 className="text-xl font-semibold">Email Content Analysis</h2>
        </div>
        
        <div className="mb-4">
          <textarea
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setError('');
            }}
            className={`w-full h-40 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
              error ? 'border-red-500' : 'border-gray-300'
            }`}
            placeholder="Paste the complete email content here (subject, body, etc.)"
          />
          {error && (
            <p className="mt-2 text-sm text-red-600">
              <AlertCircle className="w-4 h-4 inline mr-1" />
              {error}
            </p>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center text-sm text-gray-600">
            <AlertCircle className="w-4 h-4 mr-1" />
            <span>For best results, include the complete email (subject and body)</span>
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Analyze Email
          </button>
        </div>
      </div>
    </form>
  );
};