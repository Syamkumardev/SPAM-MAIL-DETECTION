import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';
import { ClassificationResult } from '../types';

interface ResultDisplayProps {
  result: ClassificationResult | null;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  if (!result) return null;

  const confidencePercentage = (result.confidence * 100).toFixed(2);

  return (
    <div className="w-full max-w-2xl mt-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-4">
          {result.isSpam ? (
            <XCircle className="w-12 h-12 text-red-500" />
          ) : (
            <CheckCircle className="w-12 h-12 text-green-500" />
          )}
          <div>
            <h3 className="text-xl font-semibold mb-2">
              {result.isSpam ? 'Spam Detected' : 'Ham (Not Spam)'}
            </h3>
            <p className="text-gray-600">
              Confidence: <span className="font-semibold">{confidencePercentage}%</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};