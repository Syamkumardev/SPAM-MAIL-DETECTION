export interface EmailData {
  content: string;
  label?: 'spam' | 'ham';
}

export interface ClassificationResult {
  isSpam: boolean;
  confidence: number;
}