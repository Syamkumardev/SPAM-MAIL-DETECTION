const SPAM_INDICATORS = [
  // Money and Finance
  'free', 'cash', 'money', 'price', 'discount', 'offer', 'deal', 'cheap',
  'earn', 'income', 'profit', 'investment', 'bank', 'account', 'credit',
  
  // Urgency
  'urgent', 'immediately', 'instant', 'now', 'hurry', 'limited', 'expires',
  
  // Prizes and Winning
  'winner', 'won', 'prize', 'lottery', 'congratulations', 'selected',
  
  // Marketing
  'marketing', 'subscribe', 'click', 'buy', 'order', 'purchase', 'sale',
  
  // Suspicious Content
  'password', 'account', 'verify', 'security', 'suspended', 'unusual',
  
  // Common Spam Phrases
  'viagra', 'pharmacy', 'medicine', 'prescription', 'weight', 'loss'
];

const calculateSpamScore = (tokens: string[]): number => {
  let spamWords = 0;
  const uniqueTokens = new Set(tokens);

  uniqueTokens.forEach(token => {
    if (SPAM_INDICATORS.includes(token)) {
      spamWords++;
    }
  });

  // Calculate confidence based on the ratio of spam words to unique words
  const confidence = spamWords / Math.max(SPAM_INDICATORS.length, 1);
  return Math.min(confidence * 3, 1); // Scale up confidence but cap at 1
};

export const analyzeEmail = (content: string): { isSpam: boolean; confidence: number } => {
  const tokens = content.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(token => token.length > 2);

  const confidence = calculateSpamScore(tokens);
  
  // Consider it spam if confidence is above 0.4
  return {
    isSpam: confidence > 0.4,
    confidence: confidence
  };
};