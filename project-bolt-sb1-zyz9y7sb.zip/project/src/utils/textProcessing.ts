export const preprocessText = (text: string): string[] => {
  // Convert to lowercase and remove special characters
  const cleaned = text.toLowerCase()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  // Simple tokenization by splitting on spaces
  return cleaned.split(' ');
};

export const createVocabulary = (texts: string[]): Map<string, number> => {
  const vocabulary = new Map<string, number>();
  let index = 0;

  texts.forEach(text => {
    const tokens = preprocessText(text);
    tokens.forEach(token => {
      if (!vocabulary.has(token)) {
        vocabulary.set(token, index++);
      }
    });
  });

  return vocabulary;
};