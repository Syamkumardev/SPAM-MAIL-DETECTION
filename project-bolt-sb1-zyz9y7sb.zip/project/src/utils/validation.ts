export const validateEmail = (content: string): { isValid: boolean; message: string } => {
  if (!content || content.trim().length === 0) {
    return { 
      isValid: false, 
      message: 'Please enter email content' 
    };
  }

  if (content.trim().length < 10) {
    return { 
      isValid: false, 
      message: 'Email content is too short for analysis' 
    };
  }

  return { isValid: true, message: '' };
};